"""Native, build-only access to Dexter's native market bindings.

The SDK does not accept private keys or submit transactions. Applications own
signing, simulation, send authorization, confirmation, and spend limits.
"""

import asyncio
import json

from ._native import Client as NativeClient, decode_pump_log, derive_pump_curve, markets, price_from_logs


class Client:
    def __init__(self, rpc_urls: str):
        self._native = NativeClient(rpc_urls)

    async def request(self, operation: str, **params):
        payload = json.dumps({"op": operation, **params}, allow_nan=False)
        result = await asyncio.to_thread(self._native.request_json, payload)
        return json.loads(result)


__all__ = ["Client", "markets"]
